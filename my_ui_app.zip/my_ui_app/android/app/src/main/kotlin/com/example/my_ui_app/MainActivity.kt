package com.example.my_ui_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
