import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

void main() {
  runApp(WishMateApp());
}

class WishMateApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WishMate',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.pinkAccent,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/add': (context) => AddBirthdayScreen(),
        '/wish': (context) => WishScreen(),
        '/reset': (context) => ResetScreen(),
      },
    );
  }
}

// ------------------------- 🎂 HOME SCREEN -------------------------
class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, dynamic>> birthdays = [];

  @override
  void initState() {
    super.initState();
    _loadBirthdays();
  }

  Future<void> _loadBirthdays() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('birthdays');
    if (data != null) {
      setState(() {
        birthdays = List<Map<String, dynamic>>.from(jsonDecode(data));
      });
    }
  }

  bool _isUpcoming(String dateStr) {
    final now = DateTime.now();
    final birthday = DateTime.parse(dateStr);
    final nextBirthday = DateTime(now.year, birthday.month, birthday.day);
    final diff = nextBirthday.difference(now).inDays;
    return diff >= 0 && diff <= 7;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("WishMate 🎉"),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.pinkAccent,
        onPressed: () => Navigator.pushNamed(context, '/add'),
        child: Icon(Icons.add),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.pink.shade50, Colors.purple.shade50],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: birthdays.isEmpty
            ? Center(
                child: Text("No birthdays added yet!",
                    style: TextStyle(fontSize: 20, color: Colors.grey[600])),
              )
            : ListView.builder(
                itemCount: birthdays.length,
                itemBuilder: (context, index) {
                  final b = birthdays[index];
                  bool upcoming = _isUpcoming(b['date']);
                  return Card(
                    margin: EdgeInsets.all(12),
                    color: upcoming ? Colors.pink[100] : Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    elevation: 6,
                    child: ListTile(
                      leading: Icon(Icons.cake, color: Colors.pinkAccent),
                      title: Text(
                        b['name'],
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text("🎈 ${b['date']}"),
                      trailing: IconButton(
                        icon: Icon(Icons.favorite, color: Colors.redAccent),
                        onPressed: () {
                          Navigator.pushNamed(context, '/wish',
                              arguments: b['name']);
                        },
                      ),
                    ),
                  );
                },
              ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(10.0),
        child: ElevatedButton.icon(
          icon: Icon(Icons.delete),
          label: Text("Reset Birthdays"),
          onPressed: () => Navigator.pushNamed(context, '/reset'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.pinkAccent,
            padding: EdgeInsets.symmetric(vertical: 12),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          ),
        ),
      ),
    );
  }
}

// ------------------------- ➕ ADD BIRTHDAY SCREEN -------------------------
class AddBirthdayScreen extends StatefulWidget {
  @override
  _AddBirthdayScreenState createState() => _AddBirthdayScreenState();
}

class _AddBirthdayScreenState extends State<AddBirthdayScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController messageController = TextEditingController();
  DateTime? selectedDate;

  Future<void> _saveBirthday() async {
    if (nameController.text.isEmpty || selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please enter name and date")),
      );
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('birthdays');
    List<Map<String, dynamic>> list = [];
    if (data != null) list = List<Map<String, dynamic>>.from(jsonDecode(data));

    list.add({
      'name': nameController.text,
      'date': selectedDate!.toIso8601String(),
      'message': messageController.text.isEmpty
          ? "Wishing you a wonderful birthday!"
          : messageController.text,
    });

    await prefs.setString('birthdays', jsonEncode(list));
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text("Birthday Added!")));
    Navigator.pushReplacementNamed(context, '/');
  }

  Future<void> _pickDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1950),
      lastDate: DateTime(2100),
    );
    if (picked != null) setState(() => selectedDate = picked);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add Birthday")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            _buildTextField(nameController, "Name", Icons.person),
            SizedBox(height: 15),
            Row(
              children: [
                Icon(Icons.calendar_today, color: Colors.pink),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    selectedDate == null
                        ? "No date selected"
                        : "${selectedDate!.toLocal()}".split(' ')[0],
                    style: TextStyle(fontSize: 16),
                  ),
                ),
                ElevatedButton(
                  onPressed: _pickDate,
                  child: Text("Pick Date"),
                ),
              ],
            ),
            SizedBox(height: 15),
            _buildTextField(
                messageController, "Custom Message (optional)", Icons.message),
            SizedBox(height: 25),
            ElevatedButton.icon(
              icon: Icon(Icons.save),
              label: Text("Save Birthday"),
              onPressed: _saveBirthday,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pinkAccent,
                padding: EdgeInsets.symmetric(vertical: 12, horizontal: 25),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String label, IconData icon) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        prefixIcon: Icon(icon, color: Colors.pink),
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
      ),
    );
  }
}

// ------------------------- 💌 WISH SCREEN -------------------------
class WishScreen extends StatefulWidget {
  @override
  _WishScreenState createState() => _WishScreenState();
}

class _WishScreenState extends State<WishScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  String? name;

  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(vsync: this, duration: Duration(seconds: 2));
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.repeat(reverse: true);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    name = ModalRoute.of(context)?.settings.arguments as String?;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pink[50],
      appBar: AppBar(title: Text("Birthday Wish")),
      body: Center(
        child: ScaleTransition(
          scale: _animation,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.cake, color: Colors.pink, size: 80),
              SizedBox(height: 20),
              Text(
                "🎉 Happy Birthday, ${name ?? 'Friend'}! 🎉",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Colors.pinkAccent),
              ),
              SizedBox(height: 20),
              Text(
                "Wishing you joy, laughter, and love today!",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ------------------------- 🗑 RESET SCREEN -------------------------
class ResetScreen extends StatelessWidget {
  Future<void> _resetData(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('birthdays');
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text("All birthdays cleared!")));
    Navigator.pushReplacementNamed(context, '/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Reset Birthdays")),
      body: Center(
        child: ElevatedButton.icon(
          icon: Icon(Icons.delete_forever),
          label: Text("Clear All Data"),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.redAccent,
            padding: EdgeInsets.symmetric(horizontal: 25, vertical: 15),
          ),
          onPressed: () => _resetData(context),
        ),
      ),
    );
  }
}
