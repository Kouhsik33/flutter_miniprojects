import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

void main() {
  runApp(CineRateApp());
}

class CineRateApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CineRate',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.redAccent,
        brightness: Brightness.light,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/add': (context) => AddReviewScreen(),
        '/details': (context) => ReviewDetailsScreen(),
        '/favorites': (context) => FavoritesScreen(),
        '/summary': (context) => SummaryScreen(),
      },
    );
  }
}

// ---------------------- MODEL CLASS ----------------------
class MovieReview {
  final String title;
  final double rating;
  final String comment;
  bool isFav;

  MovieReview({
    required this.title,
    required this.rating,
    required this.comment,
    this.isFav = false,
  });

  Map<String, dynamic> toJson() => {
        'title': title,
        'rating': rating,
        'comment': comment,
        'isFav': isFav,
      };

  static MovieReview fromJson(Map<String, dynamic> json) => MovieReview(
        title: json['title'],
        rating: json['rating'],
        comment: json['comment'],
        isFav: json['isFav'],
      );
}

// ---------------------- HOME SCREEN ----------------------
class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<MovieReview> reviews = [];

  @override
  void initState() {
    super.initState();
    loadReviews();
  }

  Future<void> loadReviews() async {
    final prefs = await SharedPreferences.getInstance();
    final savedData = prefs.getStringList('reviews') ?? [];
    setState(() {
      reviews =
          savedData.map((e) => MovieReview.fromJson(jsonDecode(e))).toList();
    });
  }

  Future<void> saveReviews() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
        'reviews', reviews.map((e) => jsonEncode(e.toJson())).toList());
  }

  void toggleFavorite(int index) async {
    setState(() {
      reviews[index].isFav = !reviews[index].isFav;
    });
    await saveReviews();
  }

  void deleteReview(int index) async {
    setState(() {
      reviews.removeAt(index);
    });
    await saveReviews();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('CineRate 🎬'),
        actions: [
          IconButton(
            icon: Icon(Icons.favorite),
            onPressed: () => Navigator.pushNamed(context, '/favorites')
                .then((_) => loadReviews()),
          ),
          IconButton(
            icon: Icon(Icons.summarize),
            onPressed: () => Navigator.pushNamed(context, '/summary'),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          Navigator.pushNamed(context, '/add').then((value) {
            if (value == true) loadReviews();
          });
        },
      ),
      body: reviews.isEmpty
          ? Center(child: Text('No reviews yet. Tap + to add one!'))
          : ListView.separated(
              itemCount: reviews.length,
              separatorBuilder: (_, __) => Divider(),
              itemBuilder: (context, index) {
                final r = reviews[index];
                return Dismissible(
                  key: Key(r.title + index.toString()),
                  background: Container(color: Colors.red),
                  onDismissed: (_) => deleteReview(index),
                  child: Card(
                    margin: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                    child: ListTile(
                      title:
                          Text("${r.title} – ${r.rating.toStringAsFixed(1)}⭐"),
                      subtitle: Text(r.comment,
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      trailing: IconButton(
                        icon: Icon(
                          r.isFav ? Icons.favorite : Icons.favorite_border,
                          color: r.isFav ? Colors.red : Colors.grey,
                        ),
                        onPressed: () => toggleFavorite(index),
                      ),
                      onTap: () => Navigator.pushNamed(context, '/details',
                          arguments: r),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

// ---------------------- ADD REVIEW SCREEN ----------------------
class AddReviewScreen extends StatefulWidget {
  @override
  State<AddReviewScreen> createState() => _AddReviewScreenState();
}

class _AddReviewScreenState extends State<AddReviewScreen> {
  final titleCtrl = TextEditingController();
  final commentCtrl = TextEditingController();
  double rating = 3.0;

  Future<void> addReview() async {
    if (titleCtrl.text.trim().isEmpty || commentCtrl.text.trim().isEmpty)
      return;

    final prefs = await SharedPreferences.getInstance();
    final savedData = prefs.getStringList('reviews') ?? [];

    MovieReview newReview = MovieReview(
      title: titleCtrl.text.trim(),
      rating: rating,
      comment: commentCtrl.text.trim(),
    );

    savedData.add(jsonEncode(newReview.toJson()));
    await prefs.setStringList('reviews', savedData);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Movie Review')),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: titleCtrl,
              decoration: InputDecoration(
                labelText: 'Movie Title',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 15),
            Text("Rating: ${rating.toStringAsFixed(1)}⭐"),
            Slider(
              value: rating,
              min: 1,
              max: 5,
              divisions: 4,
              label: rating.toStringAsFixed(1),
              onChanged: (val) => setState(() => rating = val),
            ),
            SizedBox(height: 15),
            TextField(
              controller: commentCtrl,
              decoration: InputDecoration(
                labelText: 'Your Comment',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
            SizedBox(height: 25),
            ElevatedButton.icon(
              icon: Icon(Icons.save),
              label: Text("Save Review"),
              onPressed: () async {
                await addReview();
                Navigator.pop(context, true); // signal HomeScreen to refresh
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------- REVIEW DETAILS SCREEN ----------------------
class ReviewDetailsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final MovieReview review =
        ModalRoute.of(context)!.settings.arguments as MovieReview;

    return Scaffold(
      appBar: AppBar(title: Text(review.title)),
      body: Center(
        child: AnimatedOpacity(
          opacity: 1,
          duration: Duration(seconds: 1),
          child: Card(
            margin: EdgeInsets.all(20),
            elevation: 5,
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(review.title,
                      style:
                          TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  SizedBox(height: 10),
                  Text("Rating: ${review.rating}⭐",
                      style: TextStyle(fontSize: 18, color: Colors.orange)),
                  SizedBox(height: 10),
                  Text('"${review.comment}"',
                      style: TextStyle(
                          fontSize: 16,
                          fontStyle: FontStyle.italic,
                          color: Colors.grey[700])),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------- FAVORITES SCREEN ----------------------
class FavoritesScreen extends StatefulWidget {
  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  List<MovieReview> favs = [];

  @override
  void initState() {
    super.initState();
    loadFavs();
  }

  Future<void> loadFavs() async {
    final prefs = await SharedPreferences.getInstance();
    final savedData = prefs.getStringList('reviews') ?? [];
    final allReviews =
        savedData.map((e) => MovieReview.fromJson(jsonDecode(e))).toList();
    setState(() {
      favs = allReviews.where((r) => r.isFav).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Favorite Movies')),
      body: favs.isEmpty
          ? Center(child: Text("No favorites yet!"))
          : ListView.separated(
              itemCount: favs.length,
              separatorBuilder: (_, __) => Divider(),
              itemBuilder: (context, index) {
                final r = favs[index];
                return Card(
                  margin: EdgeInsets.all(10),
                  child: ListTile(
                    title: Text(r.title),
                    subtitle: Text("${r.rating}⭐"),
                  ),
                );
              },
            ),
    );
  }
}

// ---------------------- SUMMARY SCREEN ----------------------
class SummaryScreen extends StatefulWidget {
  @override
  State<SummaryScreen> createState() => _SummaryScreenState();
}

class _SummaryScreenState extends State<SummaryScreen> {
  int total = 0;
  double avg = 0;

  @override
  void initState() {
    super.initState();
    loadSummary();
  }

  Future<void> loadSummary() async {
    final prefs = await SharedPreferences.getInstance();
    final savedData = prefs.getStringList('reviews') ?? [];
    final reviews =
        savedData.map((e) => MovieReview.fromJson(jsonDecode(e))).toList();
    if (reviews.isNotEmpty) {
      double totalRating = reviews.fold(0, (sum, r) => sum + r.rating);
      setState(() {
        total = reviews.length;
        avg = totalRating / total;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Summary")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Movies Reviewed: $total",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            LinearProgressIndicator(
              value: avg / 5,
              minHeight: 8,
              color: Colors.redAccent,
            ),
            SizedBox(height: 10),
            Text("Average Rating: ${avg.toStringAsFixed(1)}⭐",
                style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
