import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

void main() {
  runApp(MediTrackApp());
}

class MediTrackApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MediTrack',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.teal,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => DashboardScreen(),
        '/add': (context) => AddReminderScreen(),
        '/alert': (context) => AlertScreen(),
        '/reset': (context) => ResetScreen(),
      },
    );
  }
}

// ---------------------- 💊 DASHBOARD SCREEN ----------------------
class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<Map<String, dynamic>> reminders = [];

  @override
  void initState() {
    super.initState();
    _loadReminders();
  }

  Future<void> _loadReminders() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('reminders');
    if (data != null) {
      setState(() {
        reminders = List<Map<String, dynamic>>.from(jsonDecode(data));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('MediTrack 💊'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _loadReminders,
          )
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.teal,
        onPressed: () => Navigator.pushNamed(context, '/add'),
        child: Icon(Icons.add),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal.shade50, Colors.green.shade100],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: reminders.isEmpty
            ? Center(
                child: Text(
                  "No medicine reminders yet!",
                  style: TextStyle(fontSize: 20, color: Colors.grey[700]),
                ),
              )
            : ListView.builder(
                padding: EdgeInsets.all(16),
                itemCount: reminders.length,
                itemBuilder: (context, index) {
                  final r = reminders[index];
                  return Card(
                    elevation: 6,
                    margin: EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                    child: ListTile(
                      leading: Icon(Icons.medication, color: Colors.teal),
                      title: Text(
                        r['medicine'],
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        "Dosage: ${r['dosage']}\nTime: ${r['time']}",
                        style: TextStyle(fontSize: 16),
                      ),
                      trailing: IconButton(
                        icon: Icon(Icons.notifications_active,
                            color: Colors.orange),
                        onPressed: () {
                          Navigator.pushNamed(context, '/alert',
                              arguments: r['medicine']);
                        },
                      ),
                    ),
                  );
                },
              ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(10.0),
        child: ElevatedButton.icon(
          icon: Icon(Icons.delete_forever),
          label: Text("Reset All Data"),
          onPressed: () => Navigator.pushNamed(context, '/reset'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.redAccent,
            padding: EdgeInsets.symmetric(vertical: 12),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          ),
        ),
      ),
    );
  }
}

// ---------------------- ➕ ADD REMINDER SCREEN ----------------------
class AddReminderScreen extends StatefulWidget {
  @override
  _AddReminderScreenState createState() => _AddReminderScreenState();
}

class _AddReminderScreenState extends State<AddReminderScreen> {
  final TextEditingController medController = TextEditingController();
  final TextEditingController doseController = TextEditingController();
  TimeOfDay? selectedTime;

  Future<void> _saveReminder() async {
    if (medController.text.isEmpty ||
        doseController.text.isEmpty ||
        selectedTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please fill all fields")),
      );
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('reminders');
    List<Map<String, dynamic>> list = [];
    if (data != null) list = List<Map<String, dynamic>>.from(jsonDecode(data));

    final formattedTime =
        "${selectedTime!.hour.toString().padLeft(2, '0')}:${selectedTime!.minute.toString().padLeft(2, '0')}";

    list.add({
      'medicine': medController.text,
      'dosage': doseController.text,
      'time': formattedTime,
    });

    await prefs.setString('reminders', jsonEncode(list));
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text("Reminder added!")));
    Navigator.pushReplacementNamed(context, '/');
  }

  Future<void> _pickTime() async {
    final TimeOfDay? picked =
        await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (picked != null) setState(() => selectedTime = picked);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add Reminder")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            _buildTextField(medController, "Medicine Name", Icons.medication),
            SizedBox(height: 15),
            _buildTextField(
                doseController, "Dosage (e.g., 1 tablet)", Icons.numbers),
            SizedBox(height: 15),
            Row(
              children: [
                Icon(Icons.access_time, color: Colors.teal),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    selectedTime == null
                        ? "No time selected"
                        : "Selected: ${selectedTime!.format(context)}",
                    style: TextStyle(fontSize: 16),
                  ),
                ),
                ElevatedButton(
                  onPressed: _pickTime,
                  child: Text("Pick Time"),
                ),
              ],
            ),
            SizedBox(height: 25),
            ElevatedButton.icon(
              icon: Icon(Icons.save),
              label: Text("Save Reminder"),
              onPressed: _saveReminder,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                padding: EdgeInsets.symmetric(vertical: 12, horizontal: 25),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String label, IconData icon) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        prefixIcon: Icon(icon, color: Colors.teal),
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
      ),
    );
  }
}

// ---------------------- ⏰ ALERT SCREEN ----------------------
class AlertScreen extends StatefulWidget {
  @override
  _AlertScreenState createState() => _AlertScreenState();
}

class _AlertScreenState extends State<AlertScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  String? medicine;

  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(vsync: this, duration: Duration(seconds: 2));
    _fadeAnimation =
        CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.repeat(reverse: true);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    medicine = ModalRoute.of(context)?.settings.arguments as String?;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal[50],
      appBar: AppBar(title: Text("Medicine Alert")),
      body: Center(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.alarm, size: 90, color: Colors.teal),
              SizedBox(height: 20),
              Text(
                "Time for ${medicine ?? "your medicine"}!",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal[800]),
              ),
              SizedBox(height: 20),
              Text("Stay healthy and consistent 💚",
                  style: TextStyle(fontSize: 18, color: Colors.black87)),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------- 🔄 RESET SCREEN ----------------------
class ResetScreen extends StatelessWidget {
  Future<void> _resetData(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('reminders');
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text("All reminders cleared!")));
    Navigator.pushReplacementNamed(context, '/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Reset Data")),
      body: Center(
        child: ElevatedButton.icon(
          icon: Icon(Icons.delete_forever),
          label: Text("Clear All Data"),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.redAccent,
            padding: EdgeInsets.symmetric(horizontal: 25, vertical: 15),
          ),
          onPressed: () => _resetData(context),
        ),
      ),
    );
  }
}
