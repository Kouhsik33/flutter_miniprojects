import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(CrickViewApp());
}

class CrickViewApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CrickView',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/summary': (context) => SummaryScreen(),
        '/reset': (context) => ResetScreen(),
      },
    );
  }
}

// ---------------------- 🏠 HOME SCREEN ----------------------
class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int runs = 0, wickets = 0, overs = 0;

  @override
  void initState() {
    super.initState();
    _loadScore();
  }

  Future<void> _loadScore() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      runs = prefs.getInt('runs') ?? 0;
      wickets = prefs.getInt('wickets') ?? 0;
      overs = prefs.getInt('overs') ?? 0;
    });
  }

  Future<void> _saveScore() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('runs', runs);
    await prefs.setInt('wickets', wickets);
    await prefs.setInt('overs', overs);
  }

  void _updateScore(String type) {
    setState(() {
      if (type == 'run1') runs += 1;
      if (type == 'run4') runs += 4;
      if (type == 'run6') runs += 6;
      if (type == 'wicket' && wickets < 10) wickets += 1;
      if (type == 'over') overs += 1;
    });
    _saveScore();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('CrickView 🏏'),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.green.shade200, Colors.green.shade50],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Team A vs Team B",
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            Card(
              elevation: 6,
              margin: EdgeInsets.symmetric(horizontal: 20),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Text("$runs / $wickets",
                        style: TextStyle(
                            fontSize: 42,
                            fontWeight: FontWeight.bold,
                            color: Colors.green[800])),
                    Text("Overs: $overs", style: TextStyle(fontSize: 20)),
                  ],
                ),
              ),
            ),
            SizedBox(height: 30),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 15,
              children: [
                _buildActionButton(
                    "+1 Run", Colors.green, () => _updateScore('run1')),
                _buildActionButton(
                    "+4 Runs", Colors.orange, () => _updateScore('run4')),
                _buildActionButton(
                    "+6 Runs", Colors.red, () => _updateScore('run6')),
                _buildActionButton(
                    "Wicket", Colors.blueGrey, () => _updateScore('wicket')),
                _buildActionButton(
                    "Over Complete", Colors.teal, () => _updateScore('over')),
              ],
            ),
            SizedBox(height: 40),
            ElevatedButton.icon(
              icon: Icon(Icons.bar_chart),
              label: Text("View Summary"),
              onPressed: () => Navigator.pushNamed(context, '/summary'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green.shade700,
                padding: EdgeInsets.symmetric(horizontal: 25, vertical: 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton(String text, Color color, VoidCallback onPressed) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        shape: StadiumBorder(),
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      ),
      onPressed: onPressed,
      child: Text(text, style: TextStyle(fontSize: 16, color: Colors.white)),
    );
  }
}

// ---------------------- 📊 SUMMARY SCREEN ----------------------
class SummaryScreen extends StatefulWidget {
  @override
  _SummaryScreenState createState() => _SummaryScreenState();
}

class _SummaryScreenState extends State<SummaryScreen> {
  int runs = 0, wickets = 0, overs = 0;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      runs = prefs.getInt('runs') ?? 0;
      wickets = prefs.getInt('wickets') ?? 0;
      overs = prefs.getInt('overs') ?? 0;
    });
  }

  double get runRate => overs == 0 ? 0 : (runs / overs);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Match Summary")),
      body: Center(
        child: Card(
          elevation: 8,
          margin: EdgeInsets.all(20),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
          child: Padding(
            padding: const EdgeInsets.all(25.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("Final Score",
                    style:
                        TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                Text("$runs / $wickets",
                    style: TextStyle(fontSize: 40, color: Colors.green[800])),
                Text("Overs: $overs", style: TextStyle(fontSize: 22)),
                SizedBox(height: 20),
                Text("Run Rate: ${runRate.toStringAsFixed(2)}",
                    style:
                        TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
                SizedBox(height: 40),
                ElevatedButton.icon(
                  icon: Icon(Icons.refresh),
                  label: Text("Reset / New Match"),
                  onPressed: () => Navigator.pushNamed(context, '/reset'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade700,
                    padding: EdgeInsets.symmetric(horizontal: 25, vertical: 12),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------- 🔄 RESET SCREEN ----------------------
class ResetScreen extends StatelessWidget {
  Future<void> _resetData(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Match data reset successfully!")),
    );
    Navigator.pushReplacementNamed(context, '/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Reset Match")),
      body: Center(
        child: ElevatedButton.icon(
          icon: Icon(Icons.delete_forever),
          label: Text("Clear All Data"),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.redAccent,
            padding: EdgeInsets.symmetric(horizontal: 25, vertical: 15),
          ),
          onPressed: () => _resetData(context),
        ),
      ),
    );
  }
}
