import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

void main() {
  runApp(TripEaseApp());
}

class TripEaseApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TripEase',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.lightBlue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => TripListScreen(),
        '/add': (context) => AddExpenseScreen(),
        '/summary': (context) => SummaryScreen(),
        '/reset': (context) => ResetScreen(),
      },
    );
  }
}

// ------------------------- 🏠 TRIP LIST SCREEN -------------------------
class TripListScreen extends StatefulWidget {
  @override
  _TripListScreenState createState() => _TripListScreenState();
}

class _TripListScreenState extends State<TripListScreen> {
  List<Map<String, dynamic>> trips = [];

  @override
  void initState() {
    super.initState();
    _loadTrips();
  }

  Future<void> _loadTrips() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('trips');
    if (data != null) {
      setState(() {
        trips = List<Map<String, dynamic>>.from(jsonDecode(data));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('TripEase 🧳'),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.lightBlue,
        onPressed: () => Navigator.pushNamed(context, '/add'),
        child: Icon(Icons.add),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue.shade50, Colors.lightBlue.shade100],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: trips.isEmpty
            ? Center(
                child: Text(
                  "No trips added yet!",
                  style: TextStyle(fontSize: 20, color: Colors.blueGrey),
                ),
              )
            : ListView.builder(
                itemCount: trips.length,
                itemBuilder: (context, index) {
                  final trip = trips[index];
                  return Card(
                    margin: EdgeInsets.all(12),
                    elevation: 6,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: ListTile(
                      leading:
                          Icon(Icons.location_on, color: Colors.blueAccent),
                      title: Text(
                        trip['destination'],
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                          "₹${trip['amount']} | Members: ${trip['members']}"),
                    ),
                  );
                },
              ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(10.0),
        child: ElevatedButton.icon(
          icon: Icon(Icons.bar_chart),
          label: Text("View Summary"),
          onPressed: () => Navigator.pushNamed(context, '/summary'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blueAccent,
            padding: EdgeInsets.symmetric(vertical: 12),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          ),
        ),
      ),
    );
  }
}

// ------------------------- ➕ ADD EXPENSE SCREEN -------------------------
class AddExpenseScreen extends StatefulWidget {
  @override
  _AddExpenseScreenState createState() => _AddExpenseScreenState();
}

class _AddExpenseScreenState extends State<AddExpenseScreen> {
  final TextEditingController destinationController = TextEditingController();
  final TextEditingController amountController = TextEditingController();
  final TextEditingController membersController = TextEditingController();

  Future<void> _saveTrip() async {
    if (destinationController.text.isEmpty ||
        amountController.text.isEmpty ||
        membersController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please fill all fields")),
      );
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('trips');
    List<Map<String, dynamic>> trips = [];
    if (data != null) trips = List<Map<String, dynamic>>.from(jsonDecode(data));

    trips.add({
      'destination': destinationController.text,
      'amount': double.tryParse(amountController.text) ?? 0,
      'members': int.tryParse(membersController.text) ?? 1,
    });

    await prefs.setString('trips', jsonEncode(trips));
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text("Trip added!")));
    Navigator.pushReplacementNamed(context, '/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add Trip Expense")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            _buildTextField(
                destinationController, "Destination", Icons.location_on),
            SizedBox(height: 15),
            _buildTextField(
                amountController, "Total Amount (₹)", Icons.currency_rupee),
            SizedBox(height: 15),
            _buildTextField(membersController, "No. of Members", Icons.group),
            SizedBox(height: 30),
            ElevatedButton.icon(
              icon: Icon(Icons.save),
              label: Text("Save Trip"),
              onPressed: _saveTrip,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                padding: EdgeInsets.symmetric(vertical: 12, horizontal: 25),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String label, IconData icon) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        prefixIcon: Icon(icon, color: Colors.lightBlue),
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
      ),
      keyboardType: label.contains("Amount") || label.contains("Members")
          ? TextInputType.number
          : TextInputType.text,
    );
  }
}

// ------------------------- 📊 SUMMARY SCREEN -------------------------
class SummaryScreen extends StatefulWidget {
  @override
  _SummaryScreenState createState() => _SummaryScreenState();
}

class _SummaryScreenState extends State<SummaryScreen> {
  double total = 0;
  double costPerPerson = 0;
  int totalMembers = 0;

  @override
  void initState() {
    super.initState();
    _calculateSummary();
  }

  Future<void> _calculateSummary() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('trips');
    if (data != null) {
      final trips = List<Map<String, dynamic>>.from(jsonDecode(data));

      double totalAmount = 0.0;
      int membersSum = 0;

      for (var t in trips) {
        final amt = t['amount'];
        final mem = t['members'];
        totalAmount += (amt is num) ? amt.toDouble() : 0.0;
        if (mem is int) {
          membersSum += mem;
        } else if (mem is double) {
          membersSum += mem.toInt();
        } else {
          membersSum += 1;
        }
      }

      setState(() {
        total = totalAmount;
        totalMembers = membersSum;
        costPerPerson = totalMembers > 0 ? total / totalMembers : 0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Trip Summary")),
      body: Center(
        child: Card(
          elevation: 8,
          margin: EdgeInsets.all(20),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
          child: Padding(
            padding: const EdgeInsets.all(25.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("Total Trip Cost",
                    style:
                        TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                Text("₹${total.toStringAsFixed(2)}",
                    style: TextStyle(
                        fontSize: 32,
                        color: Colors.blueAccent,
                        fontWeight: FontWeight.bold)),
                SizedBox(height: 20),
                Text("Total Members: $totalMembers",
                    style: TextStyle(fontSize: 18)),
                SizedBox(height: 10),
                Text("Cost per Person: ₹${costPerPerson.toStringAsFixed(2)}",
                    style: TextStyle(fontSize: 20)),
                SizedBox(height: 30),
                ElevatedButton.icon(
                  icon: Icon(Icons.refresh),
                  label: Text("Reset All Trips"),
                  onPressed: () => Navigator.pushNamed(context, '/reset'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    padding: EdgeInsets.symmetric(horizontal: 25, vertical: 12),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ------------------------- 🗑 RESET SCREEN -------------------------
class ResetScreen extends StatelessWidget {
  Future<void> _resetData(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('trips');
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text("All trips cleared!")));
    Navigator.pushReplacementNamed(context, '/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Reset Trips")),
      body: Center(
        child: ElevatedButton.icon(
          icon: Icon(Icons.delete_forever),
          label: Text("Clear All Data"),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.redAccent,
            padding: EdgeInsets.symmetric(horizontal: 25, vertical: 15),
          ),
          onPressed: () => _resetData(context),
        ),
      ),
    );
  }
}
